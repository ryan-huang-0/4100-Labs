// --------------------------------------------------------------------- //
// You will need to modify this file.                                    //
// You may add any code you need, as long as you correctly implement the //
// required pipe_cycle_*() functions already listed in this file.        //
// In part B, you will also need to implement pipe_check_bpred().        //
// --------------------------------------------------------------------- //

// pipeline.cpp
// Implements functions to simulate a pipelined processor.

#include "pipeline.h"
#include <cstdlib>
#include <stdio.h>
#include <unistd.h>

static bool has_dependency(const PipelineLatch *reader, const PipelineLatch *writer)
{
    if (!reader->valid || !writer->valid)
        return false;
    
    // writer should come before reader
    if (writer->op_id >= reader->op_id)
        return false;

    const TraceRec *reader_rec = &reader->trace_rec;
    const TraceRec *writer_rec = &writer->trace_rec;

    /*
    * Dependency if
    * reader in is reading from same register writer is writing to
    */
    return 
        (reader_rec->src1_needed &&
        writer_rec->dest_needed &&
        reader_rec->src1_reg == writer_rec->dest_reg) ||
        
        (reader_rec->src2_needed &&
        writer_rec->dest_needed &&
        reader_rec->src2_reg == writer_rec->dest_reg) ||

        (reader_rec->cc_read && writer_rec->cc_write);


}

static bool dependency_causes_stall(const PipelineLatch *reader, const Pipeline *p)
{
    // Track most recent writers for each source operand
    // In superscalar pipeline, multiple instructions can write to the same register,
    // but only the most recent one that the reader depends on matters
    const PipelineLatch *youngest_src1 = NULL;
    const PipelineLatch *youngest_src2 = NULL;
    const PipelineLatch *youngest_cc = NULL;
    unsigned int src1_stage = 0;
    unsigned int src2_stage = 0;
    unsigned int cc_stage = 0;

    // Scan all active pipeline stages and all lanes to find 
    // any instruction dependencies
    for (unsigned int stage = ID_LATCH; stage <= MA_LATCH; stage++)
    {
        for (unsigned int lane = 0; lane < PIPE_WIDTH; lane++)
        {
            const PipelineLatch *writer = &p->pipe_latch[stage][lane];
            if (!has_dependency(reader, writer))
                continue;

            const TraceRec *reader_rec = &reader->trace_rec;
            const TraceRec *writer_rec = &writer->trace_rec;

            // ensure youngest writer is kept for src1, src2, and cc

            if (reader_rec->src1_needed &&
                writer_rec->dest_needed &&
                reader_rec->src1_reg == writer_rec->dest_reg &&
                (!youngest_src1 || writer->op_id > youngest_src1->op_id))
            {
                youngest_src1 = writer;
                src1_stage = stage;
            }

            if (reader_rec->src2_needed &&
                writer_rec->dest_needed &&
                reader_rec->src2_reg == writer_rec->dest_reg &&
                (!youngest_src2 || writer->op_id > youngest_src2->op_id))
            {
                youngest_src2 = writer;
                src2_stage = stage;
            }

            if (reader_rec->cc_read && writer_rec->cc_write &&
                (!youngest_cc || writer->op_id > youngest_cc->op_id))
            {
                youngest_cc = writer;
                cc_stage = stage;
            }
        }
    }


    const PipelineLatch *youngest[] = {youngest_src1, youngest_src2, youngest_cc};
    const unsigned int stages[] = {src1_stage, src2_stage, cc_stage};

    for (unsigned int i = 0; i < 3; i++)
    {
        const PipelineLatch *writer = youngest[i];
        if (!writer)
            continue;

        const unsigned int stage = stages[i];

        /*
        * Stall if:
        * Writer still in ID_Latch
        * Writer is in EX and it is a load instruction (load-use hazard) or no forwarding
        * Writer is in MA_LATCH and forwarding disabled
        */ 
        if (stage == ID_LATCH ||
            (stage == EX_LATCH &&
             (writer->trace_rec.op_type == OP_LD || !ENABLE_EXE_FWD)) ||
            (stage == MA_LATCH && !ENABLE_MEM_FWD))
            return true;
    }

    // No stall needed if all dependencies can be forwarded or already passed
    return false;
}

/**
 * Read a single trace record from the trace file and use it to populate the
 * given fetch_op.
 * 
 * You should not modify this function.
 * 
 * @param p the pipeline whose trace file should be read
 * @param fetch_op the PipelineLatch struct to populate
 */
void pipe_get_fetch_op(Pipeline *p, PipelineLatch *fetch_op)
{
    TraceRec *trace_rec = &fetch_op->trace_rec;
    uint8_t *trace_rec_buf = (uint8_t *)trace_rec;
    size_t bytes_read_total = 0;
    ssize_t bytes_read_last = 0;
    size_t bytes_left = sizeof(*trace_rec);

    // Read a total of sizeof(TraceRec) bytes from the trace file.
    while (bytes_left > 0)
    {
        bytes_read_last = read(p->trace_fd, trace_rec_buf, bytes_left);
        if (bytes_read_last <= 0)
        {
            // EOF or error
            break;
        }

        trace_rec_buf += bytes_read_last;
        bytes_read_total += bytes_read_last;
        bytes_left -= bytes_read_last;
    }

    // Check for error conditions.
    if (bytes_left > 0 || trace_rec->op_type >= NUM_OP_TYPES)
    {
        fetch_op->valid = false;
        p->halt_op_id = p->last_op_id;

        if (p->last_op_id == 0)
        {
            p->halt = true;
        }

        if (bytes_read_last == -1)
        {
            fprintf(stderr, "\n");
            perror("Couldn't read from pipe");
            return;
        }

        if (bytes_read_total == 0)
        {
            // No more trace records to read
            return;
        }

        // Too few bytes read or invalid op_type
        fprintf(stderr, "\n");
        fprintf(stderr, "Error: Invalid trace file\n");
        return;
    }

    // Got a valid trace record!
    fetch_op->valid = true;
    fetch_op->stall = false;
    fetch_op->is_mispred_cbr = false;
    fetch_op->op_id = ++p->last_op_id;
}

/**
 * Allocate and initialize a new pipeline.
 * 
 * You should not need to modify this function.
 * 
 * @param trace_fd the file descriptor from which to read trace records
 * @return a pointer to a newly allocated pipeline
 */
Pipeline *pipe_init(int trace_fd)
{
    printf("\n** PIPELINE IS %d WIDE **\n\n", PIPE_WIDTH);

    // Allocate pipeline.
    Pipeline *p = (Pipeline *)calloc(1, sizeof(Pipeline));

    // Initialize pipeline.
    p->trace_fd = trace_fd;
    p->halt_op_id = (uint64_t)(-1) - 3;

    // Allocate and initialize a branch predictor if needed.
    if (BPRED_POLICY != BPRED_PERFECT)
    {
        p->b_pred = new BPred(BPRED_POLICY);
    }

    return p;
}

/**
 * Print out the state of the pipeline latches for debugging purposes.
 * 
 * You may use this function to help debug your pipeline implementation, but
 * please remove calls to this function before submitting the lab.
 * 
 * @param p the pipeline
 */
void pipe_print_state(Pipeline *p)
{
    printf("\n--------------------------------------------\n");
    printf("Cycle count: %lu, retired instructions: %lu\n",
           (unsigned long)p->stat_num_cycle,
           (unsigned long)p->stat_retired_inst);

    // Print table header
    for (uint8_t latch_type = 0; latch_type < NUM_LATCH_TYPES; latch_type++)
    {
        switch (latch_type)
        {
        case IF_LATCH:
            printf(" IF:    ");
            break;
        case ID_LATCH:
            printf(" ID:    ");
            break;
        case EX_LATCH:
            printf(" EX:    ");
            break;
        case MA_LATCH:
            printf(" MA:    ");
            break;
        default:
            printf(" ------ ");
        }
    }
    printf("\n");

    // Print row for each lane in pipeline width
    for (uint8_t i = 0; i < PIPE_WIDTH; i++)
    {
        for (uint8_t latch_type = 0; latch_type < NUM_LATCH_TYPES;
             latch_type++)
        {
            if (p->pipe_latch[latch_type][i].valid)
            {
                printf(" %6lu ",
                       (unsigned long)p->pipe_latch[latch_type][i].op_id);
            }
            else
            {
                printf(" ------ ");
            }
        }
        printf("\n");
    }
    printf("\n");
}

/**
 * Simulate one cycle of all stages of a pipeline.
 * 
 * You should not need to modify this function except for debugging purposes.
 * If you add code to print debug output in this function, remove it or comment
 * it out before you submit the lab.
 * 
 * @param p the pipeline to simulate
 */
void pipe_cycle(Pipeline *p)
{
    p->stat_num_cycle++;

    // In hardware, all pipeline stages execute in parallel, and each pipeline
    // latch is populated at the start of the next clock cycle.

    // In our simulator, we simulate the pipeline stages one at a time in
    // reverse order, from the Write Back stage (WB) to the Fetch stage (IF).
    // We do this so that each stage can read from the latch before it and
    // write to the latch after it without needing to "double-buffer" the
    // latches.

    // Additionally, it means that earlier pipeline stages can know about
    // stalls triggered in later pipeline stages in the same cycle, as would be
    // the case with hardware stall signals asserted by combinational logic.

    pipe_cycle_WB(p);
    pipe_cycle_MA(p);
    pipe_cycle_EX(p);
    pipe_cycle_ID(p);
    pipe_cycle_IF(p);

    // You can uncomment the following line to print out the pipeline state
    // after each clock cycle for debugging purposes.
    // Make sure you comment it out or remove it before you submit the lab.
    // pipe_print_state(p);
}

/**
 * Simulate one cycle of the Write Back stage (WB) of a pipeline.
 * 
 * Some skeleton code has been provided for you. You must implement anything
 * else you need for the pipeline simulation to work properly.
 * 
 * @param p the pipeline to simulate
 */
void pipe_cycle_WB(Pipeline *p)
{
    for (unsigned int i = 0; i < PIPE_WIDTH; i++)
    {
        if (p->pipe_latch[MA_LATCH][i].valid)
        {
            p->stat_retired_inst++;

            if (p->pipe_latch[MA_LATCH][i].op_id >= p->halt_op_id)
            {
                // Halt the pipeline if we've reached the end of the trace.
                p->halt = true;
            }
        }
    }
}

/**
 * Simulate one cycle of the Memory Access stage (MA) of a pipeline.
 * 
 * Some skeleton code has been provided for you. You must implement anything
 * else you need for the pipeline simulation to work properly.
 * 
 * @param p the pipeline to simulate
 */
void pipe_cycle_MA(Pipeline *p)
{
    for (unsigned int i = 0; i < PIPE_WIDTH; i++)
    {
        // Copy each instruction from the EX latch to the MA latch.
        p->pipe_latch[MA_LATCH][i] = p->pipe_latch[EX_LATCH][i];
    }
}

/**
 * Simulate one cycle of the Execute stage (EX) of a pipeline.
 * 
 * Some skeleton code has been provided for you. You must implement anything
 * else you need for the pipeline simulation to work properly.
 * 
 * @param p the pipeline to simulate
 */
void pipe_cycle_EX(Pipeline *p)
{
    for (unsigned int i = 0; i < PIPE_WIDTH; i++)
    {
        // Copy each instruction from the ID latch to the EX latch.
        p->pipe_latch[EX_LATCH][i] = p->pipe_latch[ID_LATCH][i];
    }
}

/**
 * Simulate one cycle of the Instruction Decode stage (ID) of a pipeline.
 * 
 * Some skeleton code has been provided for you. You must implement anything
 * else you need for the pipeline simulation to work properly.
 * 
 * @param p the pipeline to simulate
 */
void pipe_cycle_ID(Pipeline *p)
{
    // Move fetch bundle into ID before checking dependencies
    for (unsigned int i = 0; i < PIPE_WIDTH; i++)
    {
        p->pipe_latch[ID_LATCH][i] = p->pipe_latch[IF_LATCH][i];
        p->pipe_latch[IF_LATCH][i].stall = false;
    }

    for (unsigned int i = 0; i < PIPE_WIDTH; i++)
    {
        PipelineLatch *reader = &p->pipe_latch[ID_LATCH][i];
        bool dependency = false;

        if (reader->valid)
        {
            // Check older instructions in the same IF bundle
            for (unsigned int j = 0; j < PIPE_WIDTH; j++)
            {
                if (has_dependency(reader, &p->pipe_latch[ID_LATCH][j]))
                {
                    dependency = true;
                    break;
                }
            }

            dependency = dependency_causes_stall(reader, p);
        }

        if (dependency)
        {
            reader->valid = false;
            p->pipe_latch[IF_LATCH][i].stall = true;

            // Preserve in-order issue across lanes
            for (unsigned int j = 0; j < PIPE_WIDTH; j++)
            {
                if (p->pipe_latch[ID_LATCH][j].valid &&
                    p->pipe_latch[ID_LATCH][j].op_id > reader->op_id)
                {
                    p->pipe_latch[ID_LATCH][j].valid = false;
                    p->pipe_latch[IF_LATCH][j].stall = true;
                }
            }
        }
    }
}

/**
 * Simulate one cycle of the Instruction Fetch stage (IF) of a pipeline.
 * 
 * Some skeleton code has been provided for you. You must implement anything
 * else you need for the pipeline simulation to work properly.
 * 
 * @param p the pipeline to simulate
 */
void pipe_cycle_IF(Pipeline *p)
{
    for (unsigned int i = 0; i < PIPE_WIDTH; i++)
    {
        // freeze IF if ahead instruction is stalled
        if (p->pipe_latch[IF_LATCH][i].stall)
        {
            continue;
        }

        // Read an instruction from the trace file.
        PipelineLatch fetch_op;
        pipe_get_fetch_op(p, &fetch_op);

        // Handle branch (mis)prediction.
        if (BPRED_POLICY != BPRED_PERFECT)
        {
            pipe_check_bpred(p, &fetch_op);
        }

        // Copy the instruction to the IF latch.
        p->pipe_latch[IF_LATCH][i] = fetch_op;
    }
}

/**
 * If the instruction just fetched is a conditional branch, check for a branch
 * misprediction, update the branch predictor, and set appropriate flags in the
 * pipeline.
 * 
 * You must implement this function in part B of the lab.
 * 
 * @param p the pipeline
 * @param fetch_op the pipeline latch containing the operation fetched
 */
void pipe_check_bpred(Pipeline *p, PipelineLatch *fetch_op)
{
    // TODO: For a conditional branch instruction, get a prediction from the
    // branch predictor.

    // TODO: If the branch predictor mispredicted, mark the fetch_op
    // accordingly.

    // TODO: Immediately update the branch predictor.

    // TODO: If needed, stall the IF stage by setting the flag
    // p->fetch_cbr_stall.
}
